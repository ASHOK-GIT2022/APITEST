package RestAssured;
import static io.restassured.RestAssured.given;

import static org.testng.Assert.assertEquals;

 

import java.text.ParseException;

import java.text.SimpleDateFormat;

import java.util.Collections;

import java.util.Date;

import java.util.List;

 

import org.testng.annotations.Test;

 

 

import org.testng.Assert;

 

import io.restassured.RestAssured;

import io.restassured.path.json.JsonPath;
public class APITesting {
	@Test

    public void test() throws ParseException

   

    {

         

         

           RestAssured.baseURI="https://samples.openweathermap.org";

          String response=given().log().all().queryParam("q","London").

                       queryParam("q","us").

                        queryParam("appid","b6907d289e10d714a6e88b30761fae22").

                        when().get("/data/2.5/forecast/hourly/").

                        then().extract().asString();

         

          System.out.println(response);

          String resp=null;

         

          JsonPath js = new JsonPath(response);

         

         

          // Is the response contains 4 days of data

         

          SimpleDateFormat obj = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");

          List <String>dt_count = js.get("list.dt_txt");

          Collections.sort(dt_count);

          String start_date = dt_count.get(0);

          String end_date = dt_count.get(dt_count.size()-1);



          System.out.println("Start Date "+start_date);

          System.out.println("End Date "+end_date);



          Date st_date = obj.parse(start_date);

          Date ed_date = obj.parse(end_date);



          long days_diff = ed_date.getDate() - st_date.getDate();

          System.out.println("Difference of Days is "+ days_diff);



          int count=js.getInt("cnt");

         

          Assert.assertEquals(days_diff,4, "response not contains 4 days data");

         

          //2nd Test case

         

          boolean bflag = false;

          Date Date1 ,Date2;

          for(int i = 0;i<count-1;i++) {

          int j=i+1;

          Date1 = obj.parse(js.getString("list.dt_txt["+i+"]"));

          Date2 = obj.parse(js.getString("list.dt_txt["+j+"]"));

          long s_time = Date2.getTime()- Date1.getTime();

          if(((s_time/(1000*60*60))%24)==1) {

          bflag = true;

          }

          }

          if(bflag==true) {

          System.out.println("Difference is 1 Hour");

          }

          //. For all 4 days, the temp should not be less than temp_min and not more than temp_max

         

         

          boolean flag = false;

          for (int i=0 ;i<count;i++)

          {

                 float temp=js.getFloat("list.main.temp["+i+"]");

                 float temp_min=js.getFloat("list.main.temp_min["+i+"]");

                 float temp_max=js.getFloat("list.main.temp_max["+i+"]");

                 if (temp<temp_min)

                 {

                       System.out.println("temp is less then the min temp");

                       break;

                 }

                 else if(temp>temp_max)

                 {

                       System.out.println("temp is greater then the max temp");

                       break;

                 }

                 else

                 {

                       flag=true;

                 }

          }

         

          Assert.assertEquals(flag,true,"All 4 days temp is not correct");

         

         

          //If the weather id is 500, the description should be light rain

          //If the weather id is 800, the description should be a clear sky 

         

          for (int j=0 ;j<count;j++)

          {

                

         

          String wethearID=js.getString("list.weather.id["+j+"]");

          String wethearDescription=js.getString("list.weather.description["+j+"]");

          if ("[500]".equalsIgnoreCase(wethearID))

          {

                 //System.out.println("message");

                 Assert.assertEquals(wethearDescription, "[light rain]","Wether id 500 does not have wether description as light rain" );

          }

          else if ("[800]".equalsIgnoreCase(wethearID))

          {

                 Assert.assertEquals(wethearDescription, "[clear sky]","Wether id 800 does not have wether description as clear sky" );



          }

    }

    }     

}
